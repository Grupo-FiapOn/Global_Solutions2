//importar imagens:
//import nomedaimagem from "./../imagens/nomedaimagem.png
import '../css/styles.css'
function ReducaoDaMortalidadeInfantil(){

    return(
        <div className="ReducaoDaMortalidadeInfantil">
            <h2>Redução Da Mortalidade Infantil</h2>
            <p>Conteúdo</p>
            {/*para inserir a imagem:
            <img src={nomedaimagem} alt='descrição da imagem' /> 
            obs: a imagem precisa estar dentro da pasta imagens*/}
        </div>
    )

}

export default ReducaoDaMortalidadeInfantil

//para inserir no App.js eu jogo lá 1) import 2) Dentro do return(<nomedoarquivo/>)